# Néon Rivals : mettre le jeu en ligne (environ 10 minutes, gratuit)

Ce dossier contient tout : `index.html` (le jeu), `server.js` (le multijoueur), `package.json` et `render.yaml`.
Personne n’a besoin de compte pour jouer : il suffit d’ouvrir ton lien.

## Étapes (Render.com + GitHub)
1. Crée un compte gratuit sur github.com.
2. Clique sur **New repository**, nomme-le `neon-rivals`, mets-le en **Public**, puis **Create repository**.
3. Clique sur **uploading an existing file**, glisse les 5 fichiers de ce dossier (index.html, server.js, package.json, render.yaml, README.md), puis **Commit changes**.
4. Va sur render.com et connecte-toi avec **Sign in with GitHub**.
5. Clique sur **New +** puis **Blueprint**, choisis ton dépôt `neon-rivals` et valide (**Apply**).
   (Sans Blueprint : **New + > Web Service**, Build command `npm install`, Start command `npm start`, instance **Free**.)
6. Attends que l’état passe à **Live** (2 à 3 minutes). L’adresse apparaît en haut : `https://neon-rivals-xxxx.onrender.com`.
7. Ouvre l’adresse, clique sur **JOUER EN LIGNE**, puis **COPIER LE LIEN D’INVITATION** et envoie-le à tes amis.

## À savoir
- Le plan gratuit s’endort après un moment sans visite : ouvre le lien une minute avant de jouer.
- Si la connexion est coupée, le jeu se reconnecte tout seul.
- 20 joueurs max par salle (selon le mode choisi). Les salles disparaissent quand elles sont vides.
- Couronne admin : entre ton code dans le menu (bouton « 👑 CODE ADMIN »). Elle est vérifiée par le serveur.
- Pour mettre à jour le jeu : remplace `index.html` dans GitHub, Render redéploie tout seul.
- Jeu solo seulement (sans multijoueur) : tu peux aussi mettre uniquement `index.html` sur Netlify Drop ou itch.io.

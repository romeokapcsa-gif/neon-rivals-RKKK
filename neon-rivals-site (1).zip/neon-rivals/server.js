// Serveur de Néon Rivals : sert le jeu (index.html) et relaie le multijoueur en WebSocket.
const crypto=require("crypto"),http=require("http"),fs=require("fs"),path=require("path"),{WebSocketServer}=require("ws");
const PORT=process.env.PORT||3000,MAX_ROOM=20,MAX_ROOMS=200;
const server=http.createServer((req,res)=>{
  if(req.url==="/health"){res.writeHead(200);return res.end("ok")}
  fs.readFile(path.join(__dirname,"index.html"),(e,d)=>{
    if(e){res.writeHead(500);return res.end("index.html introuvable")}
    res.writeHead(200,{"Content-Type":"text/html; charset=utf-8","Cache-Control":"no-cache"});res.end(d)})});
const wss=new WebSocketServer({server,maxPayload:8192});
const rooms=new Map();let nid=1;
const send=(ws,o)=>{if(ws.readyState===1)ws.send(JSON.stringify(o))};
const ADM_HASH=process.env.ADMIN_HASH||"e89322c39407c52b61b17e5f88eb7295353ae29afc15a7e340940f75ad557e0f";
const isAdmin=c=>{if(!c)return false;const a=Buffer.from(crypto.createHash("sha256").update("nr:"+String(c)).digest("hex")),b=Buffer.from(ADM_HASH);return a.length===b.length&&crypto.timingSafeEqual(a,b)};
const KEY=/^[A-Za-z_][A-Za-z0-9_]{0,15}$/,NAME=/^[a-z0-9][a-z0-9_.-]{0,47}$/;
wss.on("connection",ws=>{
  ws.alive=true;ws.room=null;ws.on("pong",()=>ws.alive=true);
  ws.on("message",raw=>{
    let m;try{m=JSON.parse(raw)}catch(e){return}
    if(m.t==="join"&&!ws.room){
      const name=String(m.r||"").toLowerCase();if(!NAME.test(name))return ws.close();
      let room=rooms.get(name);
      if(!room){if(rooms.size>=MAX_ROOMS)return ws.close();room=new Map();rooms.set(name,room)}
      if(room.size>=MAX_ROOM){send(ws,{t:"full"});return ws.close()}
      ws.id="p"+(nid++).toString(36)+Math.random().toString(36).slice(2,6);ws.admin=isAdmin(m.a);ws.room=name;room.set(ws.id,{ws,p:{}});
      send(ws,{t:"hello",id:ws.id,peers:[...room].filter(([id])=>id!==ws.id).map(([id,c])=>({id,p:c.p}))});
    }else if(m.t==="p"&&ws.room&&m.d&&typeof m.d==="object"){
      const room=rooms.get(ws.room),me=room&&room.get(ws.id);if(!me)return;
      const clean={};
      for(const k in m.d){if(!KEY.test(k)||k==="ad")continue;clean[k]=m.d[k];if(m.d[k]===null)delete me.p[k];else me.p[k]=m.d[k]}
      if(ws.admin){clean.ad=1;me.p.ad=1}
      const out=JSON.stringify({t:"p",id:ws.id,d:clean});
      for(const [id,c] of room)if(id!==ws.id&&c.ws.readyState===1)c.ws.send(out);
    }});
  ws.on("close",()=>{
    const room=ws.room&&rooms.get(ws.room);if(!room)return;
    room.delete(ws.id);const out=JSON.stringify({t:"l",id:ws.id});
    for(const [,c] of room)if(c.ws.readyState===1)c.ws.send(out);
    if(!room.size)rooms.delete(ws.room)})});
setInterval(()=>{for(const ws of wss.clients){if(!ws.alive){ws.terminate();continue}ws.alive=false;ws.ping()}},30000);
server.listen(PORT,()=>console.log("Néon Rivals sur le port "+PORT));
